public class User {

	private String userid;
	private String userName;
	private String userPassward;
	private int userAge;
	private String userEmail;
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPassward() {
		return userPassward;
	}
	public void setUserPassward(String userPassward) {
		this.userPassward = userPassward;
	}
	public int getUserAge() {
		return userAge;
	}
	public void setUserAge(int i) {
		this.userAge = i;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public static void list() {
		// TODO Auto-generated method stub
		
	}

	
	

}
