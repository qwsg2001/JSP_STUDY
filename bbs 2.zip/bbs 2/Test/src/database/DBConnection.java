package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBConnection {

    private Connection con;
    private PreparedStatement pst;
    private ResultSet rs;

    public DBConnection() {
        try {
            // 데이터베이스 연결 시도
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/tutorial?serverTimezone=UTC", "root", "wnscjf0603@");

            if (con != null) {
                System.out.println("데이터베이스 연결 성공!");
            } else {
                System.out.println("데이터베이스 연결 실패.");
            }
        } catch (ClassNotFoundException e) {
            System.out.println("JDBC 드라이버를 찾을 수 없습니다: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("데이터베이스 연결 오류: " + e.getMessage());
        }
    }

    public boolean isAdmin(String adminID, String adminPassword) {
        try {
            String SQL = "SELECT * FROM ADMIN WHERE adminID = ? AND adminPassword = ?";
            pst = con.prepareStatement(SQL);
            pst.setString(1, adminID);
            pst.setString(2, adminPassword);
            rs = pst.executeQuery();
            
            return rs.next(); // Return true if a matching admin record is found
        } catch (SQLException e) {
            System.out.println("데이터베이스 검색 오류 : " + e.getMessage());
            return false; // Return false in case of an error or if no admin with matching credentials is found
        } finally {
           
        }
    }

    // isAdmin 및 closeResources 메서드는 이전 답변에서 제공한 코드를 그대로 사용할 수 있습니다.
}