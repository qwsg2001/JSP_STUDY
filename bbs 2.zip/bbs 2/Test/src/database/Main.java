package database;

public class Main {

    public static void main(String[] args) {
        DBConnection connection = new DBConnection();
        System.out.println("관리자 여부: " + connection.isAdmin("admin", "admin"));
    }
}
