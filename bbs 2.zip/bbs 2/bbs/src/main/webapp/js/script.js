var marker = new google.maps.Marker({
    position: new google.maps.LatLng(lat, lng),
    map: map,
    title: name
});

google.maps.event.addListener(marker, 'click', function () {
    infoWindow.setContent(name);
    infoWindow.open(map, marker);
});
