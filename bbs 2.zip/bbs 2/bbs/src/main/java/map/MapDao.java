package map;

import java.sql.*;
import java.util.ArrayList;
import java.util.*;

public class MapDao {
    private String jdbcURL = "jdbc:mysql://localhost:3306/pharmacy_db";
    private String jdbcUsername = "root";
    private String jdbcPassword = "wnscjf0603@";

    private static final String SELECT_ALL_PHARMACIES = "SELECT * FROM pharmacies";

    public MapDao() {
    }

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return connection;
    }

    public List<Pharmacy> getAllPharmacies() {
        List<Pharmacy> pharmacies = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_PHARMACIES);) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                double latitude = rs.getDouble("latitude");
                double longitude = rs.getDouble("longitude");
                String address = rs.getString("address");
                pharmacies.add(new Pharmacy(id, name, latitude, longitude, address));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return pharmacies;
    }
}