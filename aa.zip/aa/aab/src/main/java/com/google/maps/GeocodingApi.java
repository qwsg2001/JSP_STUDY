package com.google.maps;

public class GeocodingApi {

	public static Object geocode(GeoApiContext context, String address) {
		// TODO Auto-generated method stub
		return null;
	}

}
