package com.google.maps;

public class GeoApiContext {

	public class Builder {

		public Object apiKey(String string) {
			// TODO Auto-generated method stub
			return null;
		}

	}

}
