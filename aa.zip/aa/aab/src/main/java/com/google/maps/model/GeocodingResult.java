package com.google.maps.model;

public class GeocodingResult {

	public Object geometry;

}
