package map;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MapDao {

	String dbURL = "jdbc:mysql://localhost:3306/BBS?serverTimezone=UTC";
	String dbUsername = "root";
    String dbPassword = "root";
    

    private static final String SELECT_ALL_PHARMACIES = "select * from pharmacies";

    public List<Pharmacy> getAllPharmacies() {
        List<Pharmacy> pharmacies = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(dbURL, dbUsername, dbPassword);
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_PHARMACIES);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                double latitude = resultSet.getDouble("latitude");
                double longitude = resultSet.getDouble("longitude");
                String address = resultSet.getString("address");
                
                Pharmacy pharmacy = new Pharmacy(id, name, latitude, longitude, address);
                pharmacies.add(pharmacy);

            }

        } catch (SQLException e) {
            e.printStackTrace();
            // 예외 처리 코드 추가 (로그 남기기 또는 예외 전파 등)
        }

        return pharmacies;
    }
}
